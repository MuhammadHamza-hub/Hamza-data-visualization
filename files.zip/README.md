# CodeAlpha_Data_Visualization

Task 3 of the CodeAlpha Data Analytics internship: Data Visualization.

## Dataset
1,000 books scraped from books.toscrape.com (Task 1), cleaned in Task 2 (`data/books_clean.csv`).

## Charts
| # | Chart | Question |
|---|---|---|
| 1 | Bar chart | How are ratings distributed? |
| 2 | Histogram | What is a typical price? |
| 3 | Box plot | Do higher-rated books cost more? |
| 4 | 100% stacked bar | Does rating quality differ by price tier? |
| 5 | Heatmap | Where do price tiers and ratings overlap? |
| 6 | Horizontal bar | Which books are most expensive? |
| - | Dashboard | All key views in one image |

All charts are saved to `images/`.

## How to run
1. Put `books_clean.csv` (from Task 2) or `books_raw.csv` (from Task 1) in `data/`.
2. Run:
```bash
pip install -r requirements.txt
jupyter notebook Data_Visualization.ipynb
```
3. Run all cells.

## Design principles
Titles state the finding, one question per chart, labelled axes, consistent palette, chart type matched to the question.

## Key findings
(Add your own after running the notebook.)
